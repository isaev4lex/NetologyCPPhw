#include "dbmanager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QDateTime>
#include <QDir>
#include <QCoreApplication>

DbManager::DbManager(QObject *parent) : QObject(parent)
{
    open();
    ensureSchema();
    seedIfEmpty();
}

DbManager::~DbManager()
{
    if (m_db.isOpen()) m_db.close();
}

bool DbManager::open()
{
    if (m_db.isOpen()) return true;
    const QString dbPath = QDir(QCoreApplication::applicationDirPath()).filePath("inspector.db");
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(dbPath);
    const bool ok = m_db.open();
    if (ok) {
        QSqlQuery q; q.exec("PRAGMA foreign_keys = ON;");
    }
    return ok;
}

bool DbManager::ensureSchema()
{
    QSqlQuery q;

    // airports
    if (!q.exec("CREATE TABLE IF NOT EXISTS airports ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "code TEXT UNIQUE NOT NULL,"
                "name TEXT NOT NULL,"
                "city TEXT NOT NULL"
                ");")) return false;

    // flights
    if (!q.exec("CREATE TABLE IF NOT EXISTS flights ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "depart_code TEXT NOT NULL,"
                "arrive_code TEXT NOT NULL,"
                "depart_time TEXT NOT NULL,"   -- ISO 'YYYY-MM-DD HH:MM'
                "arrive_time TEXT NOT NULL,"
                "airline TEXT NOT NULL,"
                "price REAL NOT NULL,"
                "FOREIGN KEY(depart_code) REFERENCES airports(code),"
                "FOREIGN KEY(arrive_code) REFERENCES airports(code)"
                ");")) return false;

    // bookings
    if (!q.exec("CREATE TABLE IF NOT EXISTS bookings ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                "flight_id INTEGER NOT NULL,"
                "passenger_name TEXT NOT NULL,"
                "passport TEXT NOT NULL,"
                "created_at TEXT NOT NULL,"
                "FOREIGN KEY(flight_id) REFERENCES flights(id) ON DELETE CASCADE"
                ");")) return false;

    return true;
}

void DbManager::seedIfEmpty()
{
    QSqlQuery q;
    q.exec("SELECT COUNT(*) FROM airports;");
    if (q.next() && q.value(0).toInt() == 0) {
        // Пара «живых» кодов и названий
        q.exec("INSERT INTO airports(code,name,city) VALUES"
               "('SVO','Sheremetyevo','Moscow'),"
               "('DME','Domodedovo','Moscow'),"
               "('LED','Pulkovo','Saint Petersburg'),"
               "('AER','Sochi','Sochi'),"
               "('KZN','Kazan','Kazan'),"
               "('SVX','Koltsovo','Yekaterinburg')");
    }

    q.exec("SELECT COUNT(*) FROM flights;");
    if (q.next() && q.value(0).toInt() == 0) {
        // Несколько рейсов на сегодняшнюю и завтрашнюю даты
        const QString today = QDate::currentDate().toString("yyyy-MM-dd");
        const QString tom   = QDate::currentDate().addDays(1).toString("yyyy-MM-dd");

        auto ins = [&](const QString& dc, const QString& ac,
                       const QString& dep, const QString& arr,
                       const QString& al, double price){
            QSqlQuery qi;
            qi.prepare("INSERT INTO flights(depart_code,arrive_code,depart_time,arrive_time,airline,price)"
                       " VALUES(?,?,?,?,?,?)");
            qi.addBindValue(dc);
            qi.addBindValue(ac);
            qi.addBindValue(dep);
            qi.addBindValue(arr);
            qi.addBindValue(al);
            qi.addBindValue(price);
            qi.exec();
        };

        ins("SVO","LED", today+" 08:10", today+" 09:40", "Aeroflot", 79.9);
        ins("SVO","LED", today+" 19:20", today+" 20:50", "Rossiya", 68.0);
        ins("DME","AER", today+" 07:30", today+" 10:15", "S7", 99.0);
        ins("LED","SVO", today+" 21:00", today+" 22:30", "Aeroflot", 75.0);
        ins("SVO","KZN", tom  +" 06:50", tom  +" 08:40", "Aeroflot", 89.0);
        ins("SVX","LED", tom  +" 12:05", tom  +" 13:55", "Ural Airlines", 110.0);
    }
}

QList<QPair<QString, QString>> DbManager::airportsList() const
{
    QList<QPair<QString,QString>> out;
    QSqlQuery q("SELECT code,name FROM airports ORDER BY code;");
    while (q.next()) {
        out.push_back({ q.value(0).toString(), q.value(1).toString() });
    }
    return out;
}

bool DbManager::searchFlights(const QString &fromCode, const QString &toCode,
                              const QDate &date, QSqlQueryModel *intoModel)
{
    if (!intoModel) return false;
    QSqlQuery q;
    q.prepare("SELECT f.id,"
              "       f.depart_code || ' → ' || f.arrive_code AS route,"
              "       f.depart_time AS departure,"
              "       f.arrive_time AS arrival,"
              "       f.airline AS airline,"
              "       printf('%.2f', f.price) AS price"
              "  FROM flights f"
              " WHERE f.depart_code = :from"
              "   AND f.arrive_code = :to"
              "   AND date(f.depart_time) = :d"
              " ORDER BY f.depart_time ASC;");
    q.bindValue(":from", fromCode);
    q.bindValue(":to",   toCode);
    q.bindValue(":d",    date.toString("yyyy-MM-dd"));
    if (!q.exec()) return false;

    intoModel->setQuery(q);
    intoModel->setHeaderData(1, Qt::Horizontal, "Маршрут");
    intoModel->setHeaderData(2, Qt::Horizontal, "Вылет");
    intoModel->setHeaderData(3, Qt::Horizontal, "Прилёт");
    intoModel->setHeaderData(4, Qt::Horizontal, "Авиакомпания");
    intoModel->setHeaderData(5, Qt::Horizontal, "Цена");
    return true;
}

FlightInfo DbManager::flightSummary(int flightId)
{
    FlightInfo info;
    QSqlQuery q;
    q.prepare("SELECT f.id, f.depart_code, f.arrive_code, f.depart_time, f.arrive_time, f.airline, f.price,"
              "       (SELECT name FROM airports a WHERE a.code=f.depart_code),"
              "       (SELECT name FROM airports a2 WHERE a2.code=f.arrive_code)"
              "  FROM flights f WHERE f.id=:id;");
    q.bindValue(":id", flightId);
    if (q.exec() && q.next()) {
        info.ok = true;
        info.id = q.value(0).toInt();
        info.fromCode = q.value(1).toString();
        info.toCode   = q.value(2).toString();
        info.depTime  = q.value(3).toString();
        info.arrTime  = q.value(4).toString();
        info.airline  = q.value(5).toString();
        info.price    = q.value(6).toDouble();
        info.fromName = q.value(7).toString();
        info.toName   = q.value(8).toString();
    }
    return info;
}

bool DbManager::addBooking(int flightId, const QString &passengerName, const QString &passport)
{
    QSqlQuery q;
    q.prepare("INSERT INTO bookings(flight_id,passenger_name,passport,created_at)"
              " VALUES(?,?,?,?)");
    q.addBindValue(flightId);
    q.addBindValue(passengerName.trimmed());
    q.addBindValue(passport.trimmed());
    q.addBindValue(QDateTime::currentDateTime().toString(Qt::ISODate));
    return q.exec();
}

bool DbManager::loadBookings(QSqlQueryModel *intoModel)
{
    if (!intoModel) return false;
    QSqlQuery q("SELECT b.id,"
                "       b.passenger_name AS Пассажир,"
                "       b.passport AS Паспорт,"
                "       f.depart_code || ' → ' || f.arrive_code AS Маршрут,"
                "       f.depart_time AS Вылет,"
                "       printf('%.2f', f.price) AS Цена,"
                "       b.created_at AS Создано"
                "  FROM bookings b JOIN flights f ON b.flight_id=f.id"
                " ORDER BY b.id DESC;");
    intoModel->setQuery(q);
    return true;
}

bool DbManager::deleteBooking(int bookingId)
{
    QSqlQuery q;
    q.prepare("DELETE FROM bookings WHERE id=:id");
    q.bindValue(":id", bookingId);
    return q.exec();
}
