#include "bookingdialog.h"
#include "ui_bookingdialog.h"
#include <QMessageBox>

BookingDialog::BookingDialog(const FlightInfo &info, QWidget *parent)
    : QDialog(parent),
    ui(new Ui::BookingDialog)
{
    ui->setupUi(this);
    setWindowTitle("Оформление бронирования");

    ui->lbRoute->setText(QString("%1 (%2) → %3 (%4)")
                             .arg(info.fromName, info.fromCode,
                                  info.toName, info.toCode));
    ui->lbTimes->setText(QString("%1  →  %2").arg(info.depTime, info.arrTime));
    ui->lbAirline->setText(info.airline);
    ui->lbPrice->setText(QString::number(info.price, 'f', 2));

    connect(ui->buttonBox, &QDialogButtonBox::accepted, this, [this](){
        const auto name = ui->leName->text().trimmed();
        const auto pass = ui->lePassport->text().trimmed();
        if (name.isEmpty() || pass.isEmpty()) {
            QMessageBox::warning(this, "Проверка данных", "Введите ФИО и номер паспорта.");
            return;
        }
        accept();
    });
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
}

BookingDialog::~BookingDialog()
{
    delete ui;
}

QString BookingDialog::passengerName() const { return ui->leName->text().trimmed(); }
QString BookingDialog::passport() const      { return ui->lePassport->text().trimmed(); }
