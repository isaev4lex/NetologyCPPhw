#include "bookingsdialog.h"
#include "ui_bookingsdialog.h"
#include "dbmanager.h"
#include <QHeaderView>
#include <QMessageBox>

BookingsDialog::BookingsDialog(DbManager* db, QWidget* parent)
    : QDialog(parent), ui(new Ui::BookingsDialog), m_db(db), m_model(new QSqlQueryModel(this)) {
    ui->setupUi(this);
    setWindowTitle("Мои бронирования");
    ui->tvBookings->setModel(m_model);
    ui->tvBookings->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tvBookings->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tvBookings->horizontalHeader()->setStretchLastSection(true);

    connect(ui->tvBookings->selectionModel(), &QItemSelectionModel::selectionChanged,
            this, &BookingsDialog::onSelectionChanged);
    connect(ui->pbDelete, &QPushButton::clicked, this, &BookingsDialog::onDeleteClicked);
    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);

    m_db->loadBookings(m_model);
    if (m_model->columnCount() > 0) ui->tvBookings->setColumnHidden(0, true);
    ui->pbDelete->setEnabled(false);
}

BookingsDialog::~BookingsDialog(){ delete ui; }

void BookingsDialog::onSelectionChanged() {
    const auto sel = ui->tvBookings->selectionModel()->selectedRows();
    if (sel.isEmpty()) { m_selectedBookingId = -1; ui->pbDelete->setEnabled(false); return; }
    const QModelIndex idx = sel.first();
    m_selectedBookingId = m_model->data(m_model->index(idx.row(), 0)).toInt();
    ui->pbDelete->setEnabled(m_selectedBookingId > 0);
}

void BookingsDialog::onDeleteClicked() {
    if (m_selectedBookingId <= 0) return;
    if (QMessageBox::question(this, "Удаление", "Удалить выбранное бронирование?") == QMessageBox::Yes) {
        if (m_db->deleteBooking(m_selectedBookingId)) {
            m_db->loadBookings(m_model);
            if (m_model->columnCount() > 0) ui->tvBookings->setColumnHidden(0, true);
            ui->pbDelete->setEnabled(false);
        } else {
            QMessageBox::critical(this, "Ошибка", "Не удалось удалить бронирование.");
        }
    }
}
