#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include <QMessageBox>
#include <QSqlQueryModel>
#include <QDate>
#include <QHeaderView>

#include "dbmanager.h"
#include "bookingdialog.h"
#include "bookingsdialog.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow),
    m_db(new DbManager(this)),
    m_flightsModel(new QSqlQueryModel(this))
{
    ui->setupUi(this);

    // Таблица рейсов
    ui->tvFlights->setModel(m_flightsModel);
    ui->tvFlights->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tvFlights->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tvFlights->horizontalHeader()->setStretchLastSection(true);

    // Дата по умолчанию — сегодня
    ui->deDate->setDate(QDate::currentDate());

    // Заполняем аэропорты в комбобоксы
    loadAirports();

    // Сигналы
    connect(ui->pbSearch, &QPushButton::clicked, this, &MainWindow::onSearch);
    connect(ui->pbBuy,    &QPushButton::clicked, this, &MainWindow::onBuy);
    connect(ui->pbBookings, &QPushButton::clicked, this, &MainWindow::onShowBookings);
    connect(ui->tvFlights->selectionModel(), &QItemSelectionModel::selectionChanged,
            this, &MainWindow::onSelectionChanged);

    ui->pbBuy->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadAirports()
{
    const auto list = m_db->airportsList(); // код (IATA) + название
    ui->cbFrom->clear();
    ui->cbTo->clear();
    for (const auto &p : list) {
        ui->cbFrom->addItem(QString("%1 — %2").arg(p.first, p.second), p.first);
        ui->cbTo->addItem(QString("%1 — %2").arg(p.first, p.second), p.first);
    }
    if (ui->cbFrom->count() > 1 && ui->cbTo->count() > 1 && ui->cbFrom->currentIndex() == ui->cbTo->currentIndex())
        ui->cbTo->setCurrentIndex(1);
}

void MainWindow::onSearch()
{
    const QString from = ui->cbFrom->currentData().toString();
    const QString to   = ui->cbTo->currentData().toString();
    const QDate   d    = ui->deDate->date();

    if (from.isEmpty() || to.isEmpty() || from == to) {
        QMessageBox::warning(this, "Поиск", "Выберите разные аэропорты отправления и прибытия.");
        return;
    }

    if (!m_db->searchFlights(from, to, d, m_flightsModel)) {
        QMessageBox::critical(this, "Ошибка БД", "Не удалось выполнить поиск.");
        return;
    }

    // Скрываем внутренний id
    ui->tvFlights->setColumnHidden(0, true);
    m_selectedFlightId = -1;
    ui->pbBuy->setEnabled(false);
}

void MainWindow::onSelectionChanged()
{
    auto sel = ui->tvFlights->selectionModel()->selectedRows();
    if (sel.isEmpty()) {
        m_selectedFlightId = -1;
        ui->pbBuy->setEnabled(false);
        return;
    }
    const QModelIndex idx = sel.first();
    m_selectedFlightId = m_flightsModel->data(m_flightsModel->index(idx.row(), 0)).toInt();
    ui->pbBuy->setEnabled(m_selectedFlightId > 0);
}

void MainWindow::onBuy()
{
    if (m_selectedFlightId <= 0) return;

    const auto info = m_db->flightSummary(m_selectedFlightId);
    if (!info.ok) {
        QMessageBox::warning(this, "Покупка", "Не удалось получить информацию о рейсе.");
        return;
    }

    BookingDialog dlg(info, this);
    if (dlg.exec() == QDialog::Accepted) {
        if (m_db->addBooking(m_selectedFlightId, dlg.passengerName(), dlg.passport())) {
            QMessageBox::information(this, "Покупка", "Бронирование создано.");
        } else {
            QMessageBox::critical(this, "Покупка", "Не удалось создать бронирование.");
        }
    }
}

void MainWindow::onShowBookings()
{
    BookingsDialog dlg(m_db, this);
    dlg.exec();
}
